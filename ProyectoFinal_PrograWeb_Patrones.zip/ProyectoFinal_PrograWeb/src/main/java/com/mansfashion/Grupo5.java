package com.mansfashion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Grupo5 {

	public static void main(String[] args) {
		SpringApplication.run(Grupo5.class, args);
	}

}
