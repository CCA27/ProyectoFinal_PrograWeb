package com.mansfashion.service;

import com.mansfashion.domain.Producto;
import java.util.List;
import org.springframework.data.repository.query.Param;

public interface ProductoService {

    List<Producto> getProductos(boolean activos);

    Producto getProducto(Producto producto);

    Producto getProductoById(Long idProducto);

    void save(Producto producto);

    void delete(Producto producto);

    List<Producto> findByPrecioBetweenOrderByDescripcion(double precioInf, double precioSup);

    List<Producto> metodoJPQL(@Param("precioInf") double precioInf, @Param("precioSup") double precioSup);

    List<Producto> metodoNativo(@Param("precioInf") double precioInf, @Param("precioSup") double precioSup);
}