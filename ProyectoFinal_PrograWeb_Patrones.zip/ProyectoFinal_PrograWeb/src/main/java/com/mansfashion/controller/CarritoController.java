package com.mansfashion.controller;

import com.mansfashion.domain.Producto;
import com.mansfashion.domain.Item;
import com.mansfashion.service.ItemService;
import com.mansfashion.service.ProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class CarritoController {

    @Autowired
    private ItemService itemService;

    @Autowired
    private ProductoService productoService;

    @GetMapping("/")
    public String listado(Model model) {
        var productos = productoService.getProductos(false);
        model.addAttribute("productos", productos);
        return "index";
    }

    // Para ver el carrito
    @GetMapping("/carrito/listado")
    public String inicio(Model model) {
        var items = itemService.gets();
        model.addAttribute("items", items);

        // Usar stream para calcular el total de ventas
        var carritoTotalVenta = items.stream()
                                     .mapToDouble(item -> item.getCantidad() * item.getPrecio())
                                     .sum();
        
        model.addAttribute("carritoTotal", carritoTotalVenta);
        return "carrito/listado";
    }

    // Para agregar un producto al carrito
    @PostMapping("/carrito/agregar/{idProducto}")
    public ModelAndView agregarItem(@PathVariable Long idProducto, Model model) {
        Producto producto = productoService.getProductoById(idProducto);
        
        if (producto == null) {
            throw new RuntimeException("Producto no encontrado");
        }

        // Usar el método 'get' existente para buscar el Item en el carrito
        Item item = itemService.get(new Item(producto));
        
        if (item == null) {
            item = new Item(producto);
            item.setCantidad(1); // Inicializa la cantidad a 1 si es un nuevo item
        } else {
            item.setCantidad(item.getCantidad() + 1); // Aumenta la cantidad si ya existe
        }
        
        itemService.save(item);

        var lista = itemService.gets();
        var carritoTotalVenta = lista.stream()
                                     .mapToDouble(i -> i.getCantidad() * i.getPrecio())
                                     .sum();
        
        model.addAttribute("listaItems", lista);
        model.addAttribute("carritoTotal", carritoTotalVenta);
        
        return new ModelAndView("carrito/fragmentos :: verCarrito");
    }

    // Para modificar un producto del carrito
    @GetMapping("/carrito/modificar/{idProducto}")
    public String modificarItem(@PathVariable Long idProducto, Model model) {
        Item item = itemService.get(new Item(productoService.getProductoById(idProducto)));
        if (item == null) {
            throw new RuntimeException("Item no encontrado en el carrito");
        }
        model.addAttribute("item", item);
        return "carrito/modificar";
    }

    // Para eliminar un elemento del carrito
    @GetMapping("/carrito/eliminar/{idProducto}")
    public String eliminarItem(@PathVariable Long idProducto) {
        Item item = itemService.get(new Item(productoService.getProductoById(idProducto)));
        if (item != null) {
            itemService.delete(item);
        }
        return "redirect:/carrito/listado";
    }

    // Para actualizar un producto del carrito (cantidad)
    @PostMapping("/carrito/guardar")
    public String guardarItem(Item item) {
        itemService.actualiza(item);
        return "redirect:/carrito/listado";
    }

    // Para facturar los productos del carrito (no implementado)
    @GetMapping("/facturar/carrito")
    public String facturarCarrito() {
        itemService.facturar();
        return "redirect:/";
    }
}