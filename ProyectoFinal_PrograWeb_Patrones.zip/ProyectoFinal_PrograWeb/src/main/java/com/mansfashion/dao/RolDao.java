package com.mansfashion.dao;

import com.mansfashion.domain.Rol;
import org.springframework.data.jpa.repository.JpaRepository;


public interface RolDao extends JpaRepository<Rol, Long>{
    
}
